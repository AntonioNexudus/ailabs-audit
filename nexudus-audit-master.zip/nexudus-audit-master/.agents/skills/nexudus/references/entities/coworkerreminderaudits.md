# CoworkerReminderAudits

<!-- BEGIN:GENERATED entity=CoworkerReminderAudits -->

A **CoworkerReminderAudit** records when a reminder was sent to a customer at a location. Each entry links the customer to the reminder that was triggered, forming an internal audit trail of automated communications that have been dispatched.

Use these records to determine which reminders have already been sent to a specific customer, and to avoid sending duplicate communications.

CoworkerReminderAudits support Search, Get, Create, Update, Delete.

| Command | Description |
| --- | --- |
| `nexudus coworkerreminderaudits list --agent` | List all coworkerreminderaudits |
| `nexudus coworkerreminderaudits list --id <id> --agent` | Filter by single ID |
| `nexudus coworkerreminderaudits list --id <id1> --id <id2> --agent` | Filter by multiple IDs |
| `nexudus coworkerreminderaudits list --unique-id <guid> --agent` | Filter by UniqueId (GUID) |
| `nexudus coworkerreminderaudits list --coworker-id <value> --reminder-id <value> --agent` | Filter coworkerreminderaudits by properties |
| `nexudus coworkerreminderaudits list --page-number 2 --page-size 10 --agent` | Paginated list |
| `nexudus coworkerreminderaudits get <id> --agent` | Get single coworkerreminderaudit |
| `nexudus coworkerreminderaudits create --coworker-id <value> --reminder-id <value> --agent` | Create coworkerreminderaudit |
| `nexudus coworkerreminderaudits update <id> --name "New Name" --agent` | Update coworkerreminderaudit |
| `nexudus coworkerreminderaudits delete <id> --yes --agent` | Delete coworkerreminderaudit (no prompt) |

#### CoworkerReminderAudit list filter options

`--coworker-id` (long), `--reminder-id` (long), `--from-created-on` (range), `--to-created-on` (range), `--from-updated-on` (range), `--to-updated-on` (range)

#### CoworkerReminderAudit create options

`--coworker-id` (long, required), `--reminder-id` (long, required)

#### CoworkerReminderAudit update options

`--coworker-id` (long), `--reminder-id` (long)

### CoworkerReminderAudit (key fields)

`Id`, `CoworkerFullName`, `ReminderName`

<!-- END:GENERATED entity=CoworkerReminderAudits -->
