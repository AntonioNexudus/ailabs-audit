# SubscriberGroups

<!-- BEGIN:GENERATED entity=SubscriberGroups -->

SubscriberGroups support Search, Get, Create, Update, Delete.

| Command | Description |
| --- | --- |
| `nexudus subscribergroups list --agent` | List all subscribergroups |
| `nexudus subscribergroups list --id <id> --agent` | Filter by single ID |
| `nexudus subscribergroups list --id <id1> --id <id2> --agent` | Filter by multiple IDs |
| `nexudus subscribergroups list --unique-id <guid> --agent` | Filter by UniqueId (GUID) |
| `nexudus subscribergroups list --business-id <value> --name <value> --agent` | Filter subscribergroups by properties |
| `nexudus subscribergroups list --page-number 2 --page-size 10 --agent` | Paginated list |
| `nexudus subscribergroups get <id> --agent` | Get single subscribergroup |
| `nexudus subscribergroups create --business-id <value> --name <value> --agent` | Create subscribergroup |
| `nexudus subscribergroups update <id> --name "New Name" --agent` | Update subscribergroup |
| `nexudus subscribergroups delete <id> --yes --agent` | Delete subscribergroup (no prompt) |

#### SubscriberGroup list filter options

`--business-id` (long), `--name`, `--auto-add-members` (bool), `--auto-add-contacts` (bool), `--auto-add-bookings` (bool), `--auto-add-events` (bool), `--auto-add-visitors` (bool), `--auto-add-paying-members` (bool), `--from-created-on` (range), `--to-created-on` (range), `--from-updated-on` (range), `--to-updated-on` (range)

#### SubscriberGroup create options

`--business-id` (long, required), `--name` (required), `--news-letter-subscribers` (list, repeat flag), `--added-news-letter-subscribers` (list, repeat flag), `--removed-news-letter-subscribers` (list, repeat flag), `--auto-add-members` (bool), `--auto-add-contacts` (bool), `--auto-add-bookings` (bool), `--auto-add-events` (bool), `--auto-add-visitors` (bool), `--auto-add-paying-members` (bool), `--tariffs` (list, repeat flag), `--added-tariffs` (list, repeat flag), `--removed-tariffs` (list, repeat flag)

#### SubscriberGroup update options

`--business-id` (long), `--name`, `--news-letter-subscribers` (list, repeat flag), `--added-news-letter-subscribers` (list, repeat flag), `--removed-news-letter-subscribers` (list, repeat flag), `--auto-add-members` (bool), `--auto-add-contacts` (bool), `--auto-add-bookings` (bool), `--auto-add-events` (bool), `--auto-add-visitors` (bool), `--auto-add-paying-members` (bool), `--tariffs` (list, repeat flag), `--added-tariffs` (list, repeat flag), `--removed-tariffs` (list, repeat flag)

**List properties (only returned by `get`, not by `list`):** `NewsLetterSubscribers`, `AddedNewsLetterSubscribers`, `RemovedNewsLetterSubscribers`, `Tariffs`, `AddedTariffs`, `RemovedTariffs`

<!-- END:GENERATED entity=SubscriberGroups -->
