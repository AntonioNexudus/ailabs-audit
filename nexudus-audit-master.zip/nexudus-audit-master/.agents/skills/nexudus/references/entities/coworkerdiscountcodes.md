# CoworkerDiscountCodes

<!-- BEGIN:GENERATED entity=CoworkerDiscountCodes -->

A **CoworkerDiscountCode** assigns a `DiscountCode` to a specific customer, allowing the system to track per-customer redemption history and enforce individual validity windows.

Use `ValidFrom` and `ExpiresOn` to set customer-specific validity dates. These are distinct from the discount code's own `ValidFrom`/`ValidTo` and `ExpirationType`/`ExpiresIn` fields — the system enforces whichever constraint is more restrictive.

When the discount is part of the referral programme, `RefererGuid` identifies the referring customer. `BookingUniqueId` links the assignment to the specific booking where the code was originally applied.

CoworkerDiscountCodes support Search, Get, Create, Update, Delete.

| Command | Description |
| --- | --- |
| `nexudus coworkerdiscountcodes list --agent` | List all coworkerdiscountcodes |
| `nexudus coworkerdiscountcodes list --id <id> --agent` | Filter by single ID |
| `nexudus coworkerdiscountcodes list --id <id1> --id <id2> --agent` | Filter by multiple IDs |
| `nexudus coworkerdiscountcodes list --unique-id <guid> --agent` | Filter by UniqueId (GUID) |
| `nexudus coworkerdiscountcodes list --coworker-id <value> --business-id <value> --agent` | Filter coworkerdiscountcodes by properties |
| `nexudus coworkerdiscountcodes list --page-number 2 --page-size 10 --agent` | Paginated list |
| `nexudus coworkerdiscountcodes get <id> --agent` | Get single coworkerdiscountcode |
| `nexudus coworkerdiscountcodes create --coworker-id <value> --business-id <value> --discount-code-id <value> --agent` | Create coworkerdiscountcode |
| `nexudus coworkerdiscountcodes update <id> --name "New Name" --agent` | Update coworkerdiscountcode |
| `nexudus coworkerdiscountcodes delete <id> --yes --agent` | Delete coworkerdiscountcode (no prompt) |

#### CoworkerDiscountCode list filter options

`--coworker-id` (long), `--business-id` (long), `--discount-code-id` (long), `--notes`, `--valid-from` (DateTime), `--from-valid-from` (range), `--to-valid-from` (range), `--expires-on` (DateTime), `--from-expires-on` (range), `--to-expires-on` (range), `--referer-guid`, `--booking-unique-id`, `--from-created-on` (range), `--to-created-on` (range), `--from-updated-on` (range), `--to-updated-on` (range)

#### CoworkerDiscountCode create options

`--coworker-id` (long, required), `--business-id` (long, required), `--discount-code-id` (long, required), `--notes`, `--valid-from` (DateTime), `--expires-on` (DateTime), `--referer-guid`, `--booking-unique-id`

#### CoworkerDiscountCode update options

`--coworker-id` (long), `--business-id` (long), `--discount-code-id` (long), `--notes`, `--valid-from` (DateTime), `--expires-on` (DateTime), `--referer-guid`, `--booking-unique-id`

### CoworkerDiscountCode (key fields)

`Id`, `CoworkerFullName`, `DiscountCodeCode`

<!-- END:GENERATED entity=CoworkerDiscountCodes -->
