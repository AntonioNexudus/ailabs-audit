# CoworkerSettings

<!-- BEGIN:GENERATED entity=CoworkerSettings -->

A **CoworkerSetting** is an internal name/value pair used to store arbitrary customer-related settings.

Settings are scoped to a single customer (`CoworkerId`) and identified by a unique `Name` key. The value can be stored as plain text (`Value`) or in encrypted form (`EncryptedValue`) for sensitive data.

CoworkerSettings can also be accessed and managed via the Members Portal and the App Public API in the context of the logged-in customer.

CoworkerSettings support Search, Get, Create, Update, Delete.

| Command | Description |
| --- | --- |
| `nexudus coworkersettings list --agent` | List all coworkersettings |
| `nexudus coworkersettings list --id <id> --agent` | Filter by single ID |
| `nexudus coworkersettings list --id <id1> --id <id2> --agent` | Filter by multiple IDs |
| `nexudus coworkersettings list --unique-id <guid> --agent` | Filter by UniqueId (GUID) |
| `nexudus coworkersettings list --name <value> --agent` | Filter coworkersettings by properties |
| `nexudus coworkersettings list --page-number 2 --page-size 10 --agent` | Paginated list |
| `nexudus coworkersettings get <id> --agent` | Get single coworkersetting |
| `nexudus coworkersettings create --coworker-id <value> --name <value> --agent` | Create coworkersetting |
| `nexudus coworkersettings update <id> --name "New Name" --agent` | Update coworkersetting |
| `nexudus coworkersettings delete <id> --yes --agent` | Delete coworkersetting (no prompt) |

#### CoworkerSetting list filter options

`--coworker-id` (long), `--name`, `--value`, `--encrypted-value`, `--from-created-on` (range), `--to-created-on` (range), `--from-updated-on` (range), `--to-updated-on` (range)

#### CoworkerSetting create options

`--coworker-id` (long, required), `--name` (required), `--value`, `--encrypted-value`

#### CoworkerSetting update options

`--coworker-id` (long), `--name`, `--value`, `--encrypted-value`

### CoworkerSetting (key fields)

`Id`, `Name`

<!-- END:GENERATED entity=CoworkerSettings -->
