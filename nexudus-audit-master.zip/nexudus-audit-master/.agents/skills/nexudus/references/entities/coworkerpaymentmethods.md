# CoworkerPaymentMethods

<!-- BEGIN:GENERATED entity=CoworkerPaymentMethods -->

A **CoworkerPaymentMethod** is a tokenised payment method stored against a customer and a location, used when charging invoices issued to that customer by that location.

Currently supported providers are **Stripe** (card and ACH/BACS) and **GoCardless** (direct debit mandates). The `RegularPaymentProvider` field identifies the provider; valid values for this entity are `Stripe` (2), `StripeACH` (11), `StripeBACS` (13), and `GoCardless` (12).

- For Stripe methods, `MethodId` holds the Stripe payment method ID and `CustomerId` holds the Stripe customer ID.
- For GoCardless mandates, `MandateId` holds the GoCardless mandate ID and `CustomerId` holds the GoCardless customer ID.
- `CardNumber` stores a masked card number for display purposes only.

CoworkerPaymentMethods support Search, Get, Create, Update, Delete.

| Command | Description |
| --- | --- |
| `nexudus coworkerpaymentmethods list --agent` | List all coworkerpaymentmethods |
| `nexudus coworkerpaymentmethods list --id <id> --agent` | Filter by single ID |
| `nexudus coworkerpaymentmethods list --id <id1> --id <id2> --agent` | Filter by multiple IDs |
| `nexudus coworkerpaymentmethods list --unique-id <guid> --agent` | Filter by UniqueId (GUID) |
| `nexudus coworkerpaymentmethods list --coworker-id <value> --business-id <value> --agent` | Filter coworkerpaymentmethods by properties |
| `nexudus coworkerpaymentmethods list --page-number 2 --page-size 10 --agent` | Paginated list |
| `nexudus coworkerpaymentmethods get <id> --agent` | Get single coworkerpaymentmethod |
| `nexudus coworkerpaymentmethods create --coworker-id <value> --business-id <value> --agent` | Create coworkerpaymentmethod |
| `nexudus coworkerpaymentmethods update <id> --name "New Name" --agent` | Update coworkerpaymentmethod |
| `nexudus coworkerpaymentmethods delete <id> --yes --agent` | Delete coworkerpaymentmethod (no prompt) |

#### CoworkerPaymentMethod list filter options

`--coworker-id` (long), `--business-id` (long), `--regular-payment-provider` (enum), `--method-id`, `--customer-id`, `--mandate-id`, `--card-number`, `--notes`, `--from-created-on` (range), `--to-created-on` (range), `--from-updated-on` (range), `--to-updated-on` (range)

#### CoworkerPaymentMethod create options

`--coworker-id` (long, required), `--business-id` (long, required), `--regular-payment-provider` (enum), `--method-id`, `--customer-id`, `--mandate-id`, `--card-number`, `--notes`

#### CoworkerPaymentMethod update options

`--coworker-id` (long), `--business-id` (long), `--regular-payment-provider` (enum), `--method-id`, `--customer-id`, `--mandate-id`, `--card-number`, `--notes`

### CoworkerPaymentMethod (key fields)

`Id`, `BusinessName`

<!-- END:GENERATED entity=CoworkerPaymentMethods -->
