Holding folder for nexudus-audit files that are NOT uploaded to GitHub.

These were moved out of skills/nexudus-audit/ so that folder contains only the
files belonging in the shared work repo. Nothing here was deleted.

Original locations (to restore, move back):

  Health-check sheet - customer XYZ.xlsx  ->  skills/nexudus-audit/
  docs/                                   ->  skills/nexudus-audit/docs/
  .claude/                                ->  skills/nexudus-audit/.claude/
  .audit-cache/                           ->  skills/nexudus-audit/.audit-cache/
  reports/                                ->  skills/nexudus-audit/scripts/reports/   (NOTE: was under scripts/)

Why each is excluded:
  - Health-check sheet ... .xlsx : internal consultant worksheet, not part of the tool.
  - docs/ : maps the Excel sheet to audit.js; references the xlsx, internal-only.
  - .claude/ : local machine permissions / MCP config.
  - .audit-cache/ : runtime cache (may hold customer data); gitignored anyway.
  - reports/ : GENERATED reports. The .html contains REAL customer PII. Never upload.

audit.js recreates scripts/reports/ and .audit-cache/ automatically on the next run.
