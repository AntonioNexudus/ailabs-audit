# Nexudus Health Check — Excel manual checklist ↔ `audit.js`, and the role of the MCP server

This document answers two questions:

1. **What does the Nexudus MCP server add to the audit, and does it replace the skill?**
2. **How do the manual checks in `Health-check sheet - customer XYZ.xlsx` map to the automated checks in `scripts/audit.js`, and which are missing?**

It is a reference/analysis doc. It does **not** change `audit.js`, `SKILL.md`, or `README.md`.

---

## Part A — The MCP server does not replace the skill

**The Nexudus MCP server is a transport + CRUD + guide layer, not an audit engine.** It exposes:

- `nexudus_list / nexudus_get / nexudus_create / nexudus_update / nexudus_delete / nexudus_run_command`
- discovery: `nexudus_list_entities`, `nexudus_describe_entity`
- guides as MCP resources: `nexudus://skill` (cross-cutting conventions) and `nexudus://entities/<apiPath>` (per-entity docs)

What it has **none of** — and what therefore still lives entirely in the skill:

- the 34 checks themselves (the `checkX()` functions in `scripts/audit.js`)
- the check registry / severity model (`CHECK_DEFS`)
- the Quick / Medium / Thorough tiering (`CHECK_TIERS`) and dependency-driven prefetch (`CHECK_DEPS`, `prefetchAll`)
- the cross-entity joins that *are* the audit (e.g. desks × cancelled contracts, inactive coworkers × active contracts)
- report generation (`buildReport` / `buildHtmlReport`) and business-scope validation

Examples the MCP cannot produce on its own — each is a join + rule, not a single query:

| Finding | What it requires | Where |
|---|---|---|
| Floorplan desk still pointing at a **cancelled** contract | `floorplandesks` × cancelled `coworkercontracts` | `checkDesksOnCancelledContracts` |
| **Inactive** coworker still holding an **active** contract | inactive `coworkers` × non-cancelled `coworkercontracts` | `checkInactiveMembersWithActiveContracts` |
| Refundable **deposit** on a **cancelled** contract | `contractdeposits` × cancelled `coworkercontracts` | `checkDepositsOnCancelledContracts` |

### Where the MCP *does* help: the fix step

The audit already emits a ready-to-run `nexudus …` CLI string for each finding (the `fix:` field on every issue). The MCP is the natural backend for **applying** those fixes — a typed, PII-redacted alternative to shelling out to the CLI.

| Stage | Today | With MCP (fixes-only) |
|---|---|---|
| Scan / detect | `node audit.js` → CLI → `.md` + `.html` | unchanged |
| Read findings | read `.md` after explicit YES | unchanged (privacy gate kept) |
| Apply each fix | run the emitted `nexudus …` CLI string | call the equivalent MCP tool |
| Re-verify | re-run `audit.js` | `nexudus_get` the record, or re-run `audit.js` |

**Translating a `fix:` string to an MCP call** (rules from the MCP server instructions — kebab-case flags become PascalCase properties; all DateTimes must be UTC with a `Z` suffix):

| `audit.js` emits | MCP call |
|---|---|
| `nexudus discountcodes update --id 123 --active false` | `nexudus_update(entity="discountcodes", id=123, { Active: false })` |
| `nexudus coworkercontracts update --id 123 --cancellation-date 2026-05-30` | `nexudus_update(entity="coworkercontracts", id=123, { CancellationDate: "2026-05-30T00:00:00Z" })` |
| `nexudus floorplandesks update --id 123 --coworker-contract-ids ""` | `nexudus_update(entity="floorplandesks", id=123, { CoworkerContractIds: "" })` |
| `nexudus coworkerinvoices update --id 123 --draft false` | `nexudus_update(entity="coworkerinvoices", id=123, { Draft: false })` |

For list filters, use the `filterKey` value from `nexudus_describe_entity`, not the property name.

### Why the privacy gate can stay even with the MCP

MCP responses redact PII (names, emails, phones, notes…) into stable `«PII:CATEGORY:HASH»` tokens — but **IDs, dates, and numeric/structural fields are not redacted**. Every fix is keyed by a numeric ID, so remediation works perfectly on redacted data. Meanwhile the CLI-produced `.md` still contains *raw* PII, so the existing gate (explicit YES before reading `.md`; never read `.html`) remains consistent and is kept for now.

> A future option — letting the agent read MCP-sourced, already-redacted findings without the YES gate — is possible but **deferred** per this round's decision.

**Bottom line:** the MCP doesn't remove the skill. The 33-check logic lives in `scripts/audit.js`; the skill (`SKILL.md`) orchestrates it — it stays the entry point and the audit stays the engine. The MCP removes the need to shell out to the CLI for the *fix* step and gives the agent a typed, PII-safe way to action remediations and re-verify.

---

## Part B — The Excel sheet is a broader, human checklist

`Health-check sheet - customer XYZ.xlsx` is a single sheet: a consultant matrix of **7 modules** with columns:

**Module · Feature · To check · Checked pre-visit · Checked on visit · Specific characteristic · Onsite improvement · Future improvement points**

The two "Checked" columns are the key to the mapping:

- **"Checked pre-visit"** ≈ what `audit.js` can auto-populate from account data.
- **"Checked on visit"** ≈ human / process / demo / integration work the audit cannot do.

The two artifacts are **complementary, not redundant**:

- `audit.js` is **deep on Finance and Inventory data integrity** — and goes well beyond the sheet there (see the "no Excel counterpart" list below).
- The Excel is **wide across Integrations, Apps, Analytics, and Processes** — areas that are inherently manual (external systems, live demos, advisory).

---

## Part C — Mapping tables

Legend: ✅ covered · 🟡 partial · ❌ automatable gap (not in `audit.js`) · 🔵 manual-only (not automatable).

**The ❌ vs 🔵 criterion:** if the data needed to make the judgment already exists in the Nexudus API/MCP, it's an **❌ automatable gap** (a candidate future check); if the judgment requires an external system, a live demo, or human advice, it's **🔵 manual-only**.

### Inventory
| Excel feature (cell) | `audit.js` coverage | Status |
|---|---|---|
| **Plans** — per company, passes, billing day/proration, deposit structure, credits (B2) | #15 missing tax/financial acct; #28 misconfigured plan credits; #33 contract price ≠ plan price | 🟡 — proration / billing-day / passes config not checked |
| **Products** — credit/day-pass benefits, recurring settings (B3) | #7 out of stock; #15 missing tax/acct; #20 low stock; #28 misconfigured product credits | 🟡 — recurring config not checked |
| **Resources** — limits/rules, pricing, availability, advanced (B4) | #31 resources with no booking rate | 🟡 — availability/advanced rules not checked |
| **Floor plan** — setup, allocation to contract, items linked to resources (B5) | #1 desks on cancelled contracts | 🟡 — item→resource linkage / allocation correctness not checked |
| **Credits** — types & correct setup (B6) | #28 plan/product credits that grant nothing or can never be spent | ✅ data side; 🟡 — credit *types*/release rules beyond spendability not checked |

### Finance
| Excel feature (cell) | `audit.js` coverage | Status |
|---|---|---|
| **Invoices** — format, automated + one-off process (B8) | #2 overdue · #6 12-mo writeoff · #14 stale drafts · #24 overpaid · #29 partial | ✅ data side; 🔵 "format/process" review is manual |
| **Discounts** — application & methods (B9) | #13 expired-but-active · #30 impossible date range | ✅ |
| **Settings** — invoice / tax / payment settings (B10) | #15 (partial) | 🟡 — global settings review mostly manual |
| **Financial accounts** — accounts/types, chart coverage, deposits (B11) | #15 missing financial account; #10 deposits on cancelled | ✅ "all items have an account" ≈ #15 |
| **Taxes** — setup, per-product & customer-specific, country rules (B12) | #15 missing tax rate | 🟡 — customer-specific / country rules not checked |
| **Payments** — integrations (DD/cards), troubleshoot (B13) | #18 members no payment method; #11 team payer no method | 🟡 — integration health/troubleshoot is manual |
| **Accounting integration** — setup, invoice sync, errors (B14) | none | 🔵 manual (external sync/troubleshoot) |

### Integrations · Settings · Analytics · Apps · Processes
| Module | Excel features (cells) | `audit.js` coverage | Status |
|---|---|---|---|
| **Integrations** | WiFi, Door Access, Printing, Calendars (B16–B19) | none | 🔵 manual (external systems / demos) |
| **Settings** | Sign up, Booking settings, Validation rules, Imports & bulk edit (B21–B24) | none (audit reads booking *data*, not *settings*) | 🔵 mostly manual; a booking-settings sanity check is a small ❌ gap |
| **Analytics** | Reports, Nexudus Explore/Designer, Revenue forecast, Trends (B26–B29) | none | 🔵 manual (advisory / demo) |
| **Apps** | Passport/white-label, NexIO, NexBoard, NexDelivery, NexKiosk (B31–B35) | none | 🔵 manual (usage review) |
| **Processes** | Sign-up & checkout, Bookings, New-contract offices, Sales/CRM, Community (B37–B41) | #12 future bookings on archived resources (tangential) | 🔵 manual (process review) |

### `audit.js` checks with **no Excel counterpart** (the audit goes deeper than the sheet)
These data-hygiene checks aren't enumerated on the manual sheet — a strength worth surfacing:

> #3, #4, #5, #8, #9 (member/contract lifecycle) · #11 (team billing) · #16 (frozen past end date) · #17, #22, #23 (booking / check-in / charge billing leakage) · #19 (contract-limit approaching) · #21 (archived plans with active contracts) · #25 (stale operators) · #26, #27 (help desk) · #32 (duplicate emails) · #34 (duplicate contracts).

---

## Part D — Automatable gaps (candidate future checks, not implemented)

These Excel items are **not manual** — the data exists in the API/MCP, so they could become future `audit.js` checks.

> **Now implemented:** *Credits / benefits setup* (Excel B3, B6) — the highest-value gap, called out twice on the sheet — is covered as of **#28**, which flags plan/product booking credits (`tariffbookingcredits`, `productbookingcredits`) that grant nothing (amount ≤ 0) or can never be spent (not enabled for bookings, events, or products). Possible extensions still open: `coworkerbookingcredits` (released-credit hygiene) and `tariffextraservices` with zero `UsesIncluded`.

The remaining gaps are **likely automatable but need field validation** (the data plausibly exists, but the specific fields that encode the rule haven't been confirmed via `nexudus_describe_entity`):

1. **Plan billing config** (B2) — billing day / proration / deposit-structure consistency, beyond the price-override insight (#33).
2. **Resource availability & advanced rules** (B4) — beyond "no booking rate" (#31): resources with contradictory availability windows or missing limits.
3. **Floorplan item → resource linkage** (B5) — beyond desks-on-cancelled (#1): floorplan items that should map to a resource but don't.
4. **Customer-specific / country tax assignment** (B12) — beyond "missing tax rate" (#15).

Everything under **Integrations, Apps, Analytics, and Processes** is genuinely manual (external systems, live demos, advisory) and should stay in the human "Checked on visit" column.

---

## Summary

- The **MCP server complements the skill; it doesn't replace it.** Keep `audit.js`+CLI as the scan engine; use MCP as the typed, PII-redacted backend for the **fix + re-verify** step. The fix strings the audit already emits translate 1:1 to `nexudus_update` calls.
- The **Excel sheet is the wider human engagement**; `audit.js` automates (and exceeds) its "pre-visit" data checks for **Finance** and **Inventory**, while Integrations / Apps / Analytics / Processes remain manual.
- **Credits/benefits setup** — the gap the sheet calls out twice — is **now covered by #28**. **Four further automatable gaps** (Part D) remain as future-check candidates, pending field validation.

**Deferred / open questions:**

- Letting the agent read MCP-sourced, **already-redacted** findings without the explicit-YES gate (raised in Part A) is possible but deferred — the gate stays for now because the CLI-produced `.md` still contains raw PII.
